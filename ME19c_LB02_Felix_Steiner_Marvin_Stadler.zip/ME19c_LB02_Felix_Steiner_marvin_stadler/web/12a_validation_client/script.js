
const form = document.getElementById('form');
const username = document.getElementById('username');
const email = document.getElementById('email');
const tel = document.getElementById('tel');
const date = document.getElementById('date');
const genders = document.getElementsByName('gender');

// Show input error message
function showError(input, message) {
  const formControl = input.parentElement;
  formControl.className = 'form-control error';
  const small = formControl.querySelector('small');
  small.innerText = message;
}

// Show success outline
function showSuccess(input) {
  const formControl = input.parentElement;
  formControl.className = 'form-control success';
}

// Check email is valid
function checkEmail(input) {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  if (re.test(input.value.trim())) {
    showSuccess(input);
  } else {
    showError(input, 'Email is not valid');
  }
}

// Check phone is valid
function telephoneCheck(input) {
  const tel = /^(1\s|1|)?(((\d{3}))|\d{3})(-|\s)?(\d{3})(-|\s)?(\d{4})$/;
  if (tel.test(input.value.trim())) {
    showSuccess(input);
  } else {
    showError(input, 'Phone is not valid');
  }
}

// Check date is valid
function dateCheck(input) {
  const date = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/;
  if (date(input.value.trim())) {
    showSuccess(input);
  } else {
    showError(input, 'Date is not valid');
  }
}


// Check required fields
function checkRequired(inputArr) {
  let isRequired = false;
  inputArr.forEach(function(input) {
    if (input.value.trim() === '') {
      showError(input, `${getFieldName(input)} is required`);
      isRequired = true;
    } else {
      showSuccess(input);
    }
  });

  return isRequired;
}

// Check input length
function checkLength(input, min, max) {
  if (input.value.length < min) {
    showError(
        input,
        `${getFieldName(input)} must be at least ${min} characters`
    );
  } else if (input.value.length > max) {
    showError(
        input,
        `${getFieldName(input)} must be less than ${max} characters`
    );
  } else {
    showSuccess(input);
  }
}

// Get fieldname
function getFieldName(input) {
  return input.id.charAt(0).toUpperCase() + input.id.slice(1);
}

// Validate Form
function validateForm(){
  if(!checkRequired([username, email, tel, date])){
    checkLength(username, 4, 20);
    checkLength(email, 6, 40);
    checkEmail(email);
    telephoneCheck(tel);
    dateCheck(date);
  }
}

// Validate Radiobuttons
function validateRadio() {
  if (genders.checked == true) {
  } else if (genders[1].checked == true) {
  } else {
      // no checked
      var msg = '<span style="color:red;">You must select your gender!</span><br /><br />';
      document.getElementById('msg').innerHTML = msg;
      return false;
  }
  return true;
}

// Remove Error Msg when checked
function reset_msg() {
  document.getElementById('msg').innerHTML = '';
}

// Event listeners
form.addEventListener('submit', function(e) {
  e.preventDefault();
  validateForm();
  validateRadio();
});




